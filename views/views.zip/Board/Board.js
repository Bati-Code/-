import React from 'react';
import { Table } from 'ant-table-extensions';
import "antd/dist/antd.css"

const Board = () => {

    const columns = [
        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: 'Age',
            dataIndex: 'age',
            key: 'age',
        },
        {
            title: 'Address',
            dataIndex: 'address',
            key: 'address',
        },
    ];

    const data = [
        {
            key: '1',
            name: 'John Brown',
            age: 10,
            address: 60,
        },
        {
            key: '2',
            name: 'John Brown',
            age: 10,
            address: 60,
        },
        {
            key: '3',
            name: 'John Brown',
            age: 10,
            address: 60,
        },
        {
            key: '4',
            name: 'KIM',
            age: 20,
            address: 10,
        },
        {
            key: '5',
            name: 'Brown',
            age: 60,
            address: 610,
        },
    ];

    const onRow = (record, rowIndex) => {
        return {
            onClick: (event) => {
                console.log(record, rowIndex, event);
            }
        }
    }

    return (
        <div className="main">
            <Table onRow={onRow} dataSource={data} columns={columns} pagination={{pageSize: 10, position:['bottomCenter']}} searchable />
        </div>
    )

}



export default Board;


