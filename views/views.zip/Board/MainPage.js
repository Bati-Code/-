import React from 'react'
import Board from './Board'
import './css/BoardCSS.css'

const MainPage = () => {

    return (
        <>
            <div className="board_wrap">
                <div className="board_Header">
                    게시판
                </div>
                <div className="container">
                    <section className="board_content">
                        <nav>
                        </nav>
                        <main>
                            <Board></Board>
                        </main>
                        <aside>
                        </aside>
                    </section>
                </div>
                <div className="footer">
                </div>
            </div>
        </>
    )

}
export default MainPage;